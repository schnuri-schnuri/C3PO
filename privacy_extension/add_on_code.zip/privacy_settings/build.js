import utils from "/utils.js";
import vocabulary from "/vocabulary.js";
utils.buildForm(vocabulary);