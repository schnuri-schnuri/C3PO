# Privacy Extension

##Icon
The icon of this extension is cropped from https://github.com/mozilla/fxemoji


The image is licensed by the Mozilla Foundation under the Creative Commons Attribution 4.0 International (CC BY 4.0) (https://creativecommons.org/licenses/by/4.0/)